from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from simulation.disc_robot import load_disc_robot
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

import yaml


def generate_launch_description():
    urdf_file_name = 'normal.robot'
    urdf = os.path.join(
        get_package_share_directory('simulation'),
        urdf_file_name)
    
    robot = load_disc_robot(urdf)

    return LaunchDescription([
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            parameters=[{'robot_description': robot['urdf']}],),
            
        Node(
            package='simulation',
            executable='proj4a',
            name='proj4a',
            output='screen'),
    ])