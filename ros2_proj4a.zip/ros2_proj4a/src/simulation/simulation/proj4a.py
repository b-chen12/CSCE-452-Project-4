import rclpy
import numpy as np
import math
from simulation.disc_robot import load_disc_robot
from simulation.disc_robot import disc_robot_urdf
from simulation.disc_robot import load_map
from nav_msgs.msg import OccupancyGrid
from std_msgs.msg import Header
import yaml
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from simulation.disc_robot import load_disc_robot
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from tf2_ros import TransformBroadcaster, TransformStamped

from sensor_msgs.msg import LaserScan
from example_interfaces.msg import Int64
from rclpy.node import Node
from sensor_msgs.msg import PointCloud
from geometry_msgs.msg import Point32
from std_msgs.msg import Float32MultiArray
from rclpy.qos import QoSProfile

from math import sin, cos, pi
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile
from geometry_msgs.msg import Quaternion
from sensor_msgs.msg import JointState
from tf2_ros import TransformBroadcaster, TransformStamped


class RobotSimulator(Node):
    # This node publishes onto the three separate topics
    def __init__(self):
        super().__init__('RobotSimulator')

        self.occupancy_grid = self.create_publisher(OccupancyGrid, '/map', 10)
        self.tf_broadcaster = TransformBroadcaster(self)
        self.timer = self.create_timer(0.1, self.broadcast_timer_callback)

    
    def broadcast_timer_callback(self):
        t = TransformStamped()
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = 'world'
        t.child_frame_id = 'a'
        t.transform.translation.x = 0.0
        t.transform.translation.y = 0.0
        t.transform.translation.z = 0.0
        self.createMap()
        # self.occupancy_grid.publish(occupancygrid_msg)
        self.tf_broadcaster.sendTransform(t)
        
    def createMap(self):
        urdf_file_name = 'brick.world'
        urdf = os.path.join(
            get_package_share_directory('simulation'),
            urdf_file_name)
        mapinfo = load_map(urdf)
        occupancygrid_msg = OccupancyGrid()
        occupancygrid_msg.header = Header()
        occupancygrid_msg.header.frame_id = 'world'
        occupancygrid_msg.info.resolution = mapinfo['resolution']
        occupancygrid_msg.info.width = 0
        occupancygrid_msg.info.height = 1
        x = 0
        for i in range(len(mapinfo['map'])):
            if(mapinfo['map'][i] == '\n'):
                occupancygrid_msg.info.height+=1
                x = 0
            else:
                if(mapinfo['map'][i] == '#'):
                    occupancygrid_msg.data.append(1)
                elif(mapinfo['map'][i] == '.'):
                    occupancygrid_msg.data.append(0)
                x+=1
        occupancygrid_msg.info.width = x
      
        self.occupancy_grid.publish(occupancygrid_msg)



def main(args=None):
    # robot = load_disc_robot('normal.robot')
    
    # print(robot)
    rclpy.init(args=args)

    node = RobotSimulator()

    rclpy.spin(node)

    # Destroy node

    node.destroy_node()

    rclpy.shutdown()


if __name__ == '__main__':
    main()